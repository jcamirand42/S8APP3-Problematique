#!/bin/sh
echo "Yamete kudasaï !" >> /home/share/hack